package OneToOne_hibernate;

import OneToOne_hibernate_dto.AadharCard;
import OneToOne_hibernate_dto.Persone;

import java.util.List;

import OneToOne_hibernate_dao.Person_Dao;
public class Main 
{
	public static void main(String[] args) 
	{
		AadharCard aadharCard = new AadharCard();
		aadharCard.setId(102);
		aadharCard.setName("Harsh");
		aadharCard.setAddress("Karnatka");
		
		Persone person= new Persone();
//		person.setId(3);
//		person.setName("Har");
//		person.setPhone(7418529630l);
//		
		person.setAadharcard(aadharCard);
//		
		Person_Dao dao=new Person_Dao();
//		
		dao.savePerson(person);
		
//		Person_Dao dao= new Person_Dao();
//		dao.savePerson();
//
		dao.findPerson(1);
	    dao.getAllPerson();	
	}
}
