package OneToOne_hibernate;

// this coad is only one person with one aadhar card
//If will have one more aadhar card create 2nd coade & give id 2 and diffetbt info 

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import OneToOne_hibernate_dto.AadharCard;
import OneToOne_hibernate_dto.Persone;

public class Controller 
{
	public static void main(String[] args) 
	{
	   AadharCard aadharCrad= new AadharCard();
	   aadharCrad.setId(101);
	   aadharCrad.setName("deepak");
	   aadharCrad.setAddress("Maharashtra");
	   
	  Persone person  =new Persone();
	  
	  person.setId(1);
	  person.setName("deepak");
	  person.setPhone(8308152131l);
	  
	  
	  person.setAadharcard(aadharCrad);
	  
	  EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("deepak");
	  EntityManager entityManager = entityManagerFactory.createEntityManager();
	  EntityTransaction entityTransaction=entityManager.getTransaction();
	  
	  entityTransaction.begin();
	  entityManager.persist(person);
	  entityTransaction.commit();   
	}
}
