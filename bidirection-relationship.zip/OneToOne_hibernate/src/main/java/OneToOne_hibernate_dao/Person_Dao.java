package OneToOne_hibernate_dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import OneToOne_hibernate_dto.AadharCard;
import OneToOne_hibernate_dto.Persone;

public class Person_Dao 
{
	
	public EntityManager getEntityManager()
	{
		return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	}
	
	public void savePerson(Persone person)
	{
	 // EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("deepak");
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		  
		AadharCard aadharCrad= new AadharCard();
		//Person_Dao person= new Person_Dao();
		
		  entityTransaction.begin();
		  entityManager.persist(aadharCrad);
		  entityManager.persist(person);
		  entityTransaction.commit();  
	}
	
	public void deletePerson(int id)
	{
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		Persone person =entityManager.find(Persone.class, id);
		AadharCard aadharCard=person.getAadharcard();
		
		entityTransaction.begin();
		entityManager.remove(aadharCard);
		entityManager.remove(person);
		entityTransaction.commit();
	}
	
	public void deleteAadharCard(int id)
	{
	
		EntityManager entityManager= getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		
		AadharCard aadharCard = entityManager.find(AadharCard.class, id);
		entityTransaction.begin();
		entityManager.remove(aadharCard);
		entityTransaction.commit();			
	} 
	
	public void findPerson(int id)
	{
		EntityManager entityManager = getEntityManager();
		Persone person = entityManager.find(Persone.class, id);
		System.out.println(person);
	}
	
	public void getAllPerson()
	{
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("SELECT p FROM Person p");
		
		List<Persone> list= query.getResultList();
		System.out.println(list);
	}
	public void updatePerson(Persone person, int id) 
	{
		// TODO Auto-generated method stub
		EntityManager entityManager= getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		Persone dbPerson = entityManager.find(Persone.class, id);
		if(dbPerson !=null)
		{
			person.setId(id);
			person.setAadharcard(dbPerson.getAadharcard());
			entityTransaction.begin();
			entityManager.merge(person);
			entityTransaction.commit();
		}
	}
}
