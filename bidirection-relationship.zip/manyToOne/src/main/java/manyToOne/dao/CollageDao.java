package manyToOne.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import manyToOne.dto.Collage;

public class CollageDao 
{
//	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("deepak");
//	EntityManager entityManager=entityManagerFactory.createEntityManager();
//	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	 public EntityManager getEntityManager()
	   {
		   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	   }
	 
	public void saveCollage(Collage collage)
	{
//		EntityManager entityManager=getEntityManager();
//		EntityTransaction entityTransaction=entityManager.getTransaction();
//		
//		entityTransaction.begin();
//		entityManager.persist(collage);
//		entityTransaction.commit();
//		
		// TODO Auto-generated method stub
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();
		entityManager.persist(collage);
		entityTransaction.commit();
	}
}
