package manyToOne.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import manyToOne.dto.Student;


public class StudentDao 
{
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("deepak");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveStudent(Student student)
	{
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
	}
	
	public void featchStudent(int id)	
	{
		EntityManager entityManager= entityManagerFactory.createEntityManager();		
		System.out.println(entityManager.find(Student.class, id));
	}
}