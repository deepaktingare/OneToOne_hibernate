package manyToOne.Controller;
import manyToOne.dto.Collage;
import manyToOne.dto.Student;
import manyToOne.dao.StudentDao;
import manyToOne.dao.CollageDao;
import java.util.Scanner;

public class MainController 
{
	public static void main(String[] args) 
	{
	 	Scanner sc=new Scanner(System.in);
	 	
	 	StudentDao studao=new StudentDao();
	 	CollageDao colldao=new CollageDao();
	 	Collage collage=new Collage();
	 	Student student=new Student();
	 	
	 	System.out.println("Enter a the choice \n1.StudentDao   2.CollageDao");
	 	
	 	switch(sc.nextInt())
	 	{
	 	case 1:   //This case for only student dao
	 	    {
	 	    	System.out.println("Enter the choice \n1.Save Student 2.Featch Student 3.Feacth All Student data "
	 	    			+ "\n4.delete Student 5.Update Student 6. Update Student With Collage Data \n7.Exit");
	 		 	switch(sc.nextInt())
	 		 	  {
	 		 	case 1:
	 		 	{
	 		 		student.setId(1);
	 		 		student.setName("Deepak");
	 		 		student.setPhone(7057156023l);
	 		 		student.setAddress("Pune");
	 		 		
	 		 		student.setId(2);
	 		 		student.setName("rohit");
	 		 		student.setPhone(830815001l);
	 		 		student.setAddress("Pune");	
	 		 		
	 		 		student.setId(3);
	 		 		student.setName("abhijit");
	 		 		student.setPhone(8307410231l);
	 		 		student.setAddress("Pune");	
	 		 		
	 		 		student.setId(4);	 		
	 		 		student.setName("mahesh");
	 		 		student.setPhone(8308890031l);
	 		 		student.setAddress("Pune");	
	 		 		
	 		 		student.setId(5);
	 		 		student.setName("akash");
	 		 		student.setPhone(830852751l);
	 		 		student.setAddress("Pune");	
	 		 		
	 		 		studao.saveStudent(student);

	 		 	}
	 		 	break;
	 		 	
	 		 	case 2:
	 		 	{
	 		 		System.out.println("Enter student id & Featch Student : ");
	 		 		int id=sc.nextInt();
	 		 		
	 		 		studao.featchStudent(id);
	 		 	
	 		 	}
	 		 	break;
	 
	 		 	default :
	 		 		break;
	 		 	
	 		    }
	 	    }
	 	    break;
	 	    
	 	case 2: //This case is only for the CollageDao
	 	    {
	 	    	System.out.println("Enter the choice \n1.Save Collage \n2.Featch Collage \n3.Feacth All Collage data "
	 	    			+ "\n4.delete Collage \n5.Update Collage \n6. Update Student With Collage Data \n8.Exit");
	 		 	switch(sc.nextInt())
	 		 	{
	 		 	case 1:
	 		 	   {
	 		 		    collage.setName("AISSMS IOIT"); // using insert company data
		 		    	collage.setLocation("Pune");
		 		    	collage.setFees(12000000l);
		 		    	
		 		    	colldao.saveCollage(collage);
	 		 	   }
	 		 	   
	 		 	case 2:
	 		 	   {
	 //		 		   colldao.featchCollage();
	 		 	   }
	 		 	}
	 	    }
	 	}
	 	sc.close();
	}
}
