package OneToMany.Controller;
import java.util.Scanner;
import OneToMany.dao.CompanyDao;
import OneToMany.dto.Company;
import OneToMany.dto.Employee;

import java.util.ArrayList;
import java.util.List;

public class MainController 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		CompanyDao dao = new CompanyDao();
		Company company=new Company();
		List<Employee> employees= new ArrayList<Employee>();
		Employee e1=new Employee();
		Employee e2=new Employee();
		Employee e3=new Employee();
		
	    System.out.println("Enter the choice \n1.saveCompany \n2.Featch Company \n3.Featch Employee \n4.Feacth All Company data \n5.delete Company \n6.Update Emoloyee \n7.Update Company \n8. Update Company With Employee Data \n8.Exit");
	    switch(sc.nextInt())
	    {
//	    case 1:  // using insert the  employee data
//	     {
//	    //	Employee e1=new Employee();
//	    	
//	    	e1.setName("Deepak");
//	    	e1.setAddress("Pune");
//	    	e1.setPhone(8308152131l);
//	    	
//	    //	Employee e2=new Employee();
//	    	e2.setName("Rohit");
//	    	e2.setAddress("Jalna");
//	    	e2.setPhone(7057156023l);
//	    	
//	    //	Employee e3=new Employee();
//	    	e3.setName("Akshay");
//	    	e3.setAddress("Dhule");
//	    	e3.setPhone(8308459526l);
//	    	
//	    //	List<Employee> employees= new ArrayList<Employee>();
//	    	employees.add(e1);
//	    	employees.add(e2);
//	    	employees.add(e3);
//	    
//	    	
//        	//Company company=new Company(); // using insert company data
//	    	
//	    	company.setName("tcs"); // using insert company data
//	    	company.setGst("27421566gst8526");
//	    	company.setEmployees(employees);
//	    	
//	    	dao.saveCompany(company);
//	     }
//	     break;
	     
	     
	  // using featch compnay data
//	    case 2:
//	    {
//	    	System.err.println("Enter company id and fetch the company data: ");
//	    	int id=sc.nextInt();
//	    	
//	    	dao.fetchCompany(id);
//	    }
//	    break;
	    
//	    
	    // using featch employee data
//	    case 3:     
//	    {
//	     	System.err.println("Enter Employee id and fetch the employee data: ");
//	    	int id=sc.nextInt();
//	    	
//	    	dao.fetchEmployee(id);
//	    }
//	    break;
//	    
	    case 4:
	    {
	    	dao.fetchAllCompany();
	    }
	    break;
//	    
//	    case 5:
//	    {
//	    	System.out.println("Enter a employee id for delete data: ");
//	    	int id=sc.nextInt();
//	    	
//	    	dao.deleteCompany(id);
//	    }
//	    break;
//	    
	    case 6:
	    {
	    	System.out.println("Enter company id for update company gst and name : ");
	    	int id=sc.nextInt();
	    	
	    	//Company company=new Company();
	    	
	    	company.setName("Infosys");
	    	company.setGst("27421566gst8526");
	    	
	    	dao.updateCompany(company,id);
	    }
	    break;
//	    
//	    case 7:
//	    {
//	    	System.out.println("Enter company id for update Employee : ");
//	    	int id=sc.nextInt();
//	    		
//	    //	Employee e1=new Employee();
//	    	
//	    	e1.setName("Deepak");
//	    	e1.setAddress("Pune");
//	    	e1.setPhone(8308152131l);
//	    	
//	    //	Employee e2=new Employee();
//	    	e2.setName("Rohit");
//	    	e2.setAddress("Jalna");
//	    	e2.setPhone(7057156023l);
//	    	
//	    //	Employee e3=new Employee();
//	    	e3.setName("Akshay");
//	    	e3.setAddress("Dhule");
//	    	e3.setPhone(8308459526l);
//	    	
//	    //	List<Employee> employees= new ArrayList<Employee>();
//	    	employees.add(e1);
//	    	employees.add(e2);
//	    	employees.add(e3);
//	    }
//	    break;
//	    
//	    case 8:
//	    {
//	    	System.out.println("Enter company id for update Employee with company : ");
//	    	int id=sc.nextInt();
//	    	
//	    //	Employee e1=new Employee();
//	    	
//	    	e1.setName("Deepak");
//	    	e1.setAddress("Pune");
//	    	e1.setPhone(8308152131l);
//	    	
//	    //	Employee e2=new Employee();
//	    	e2.setName("Rohit");
//	    	e2.setAddress("Jalna");
//	    	e2.setPhone(7057156023l);
//	    	
//	    //	Employee e3=new Employee();
//	    	e3.setName("Akshay");
//	    	e3.setAddress("Dhule");
//	    	e3.setPhone(8308459526l);
//	    	
//	    //	List<Employee> employees= new ArrayList<Employee>();
//	    	employees.add(e1);
//	    	employees.add(e2);
//	    	employees.add(e3);
//	    
//	    	
//        	//Company company=new Company(); // using insert company data
//	    	
//	    	company.setName("tcs"); // using insert company data
//	    	company.setGst("27421566gst8526");
//	    	company.setEmployees(employees);
//	    	
//	    	dao.saveCompany(company);
//	    }
	     default:
	    	 break;
	    }
	}
	
}
