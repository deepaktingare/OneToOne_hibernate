package OneToMany.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import OneToMany.dto.Company;
import OneToMany.dto.Employee;

public class CompanyDao 
{
   public EntityManager getEntityManager()
   {
	   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
   }
   
public void saveCompany(Company company) 
  {
	// TODO Auto-generated method stub
	EntityManager entityManager=getEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	entityTransaction.begin();
	List<Employee> employees =company.getEmployees();
	
	for(Employee employee : employees)
	{
		entityManager.persist(employee);
	}
	entityManager.persist(company);
	entityTransaction.commit();
  }

  public void fetchCompany(int id) //featching all the company data
  {
	// TODO Auto-generated method stub
	EntityManager entityManager= getEntityManager();
//	Query query = entityManager.createQuery("SELECT c FROM Employee c"); //JPQL query
//	
//	Company company= entityManager.find(Company.class, id);
//	System.out.println(company);
	
                       // OR	
	
	System.out.println(entityManager.find(Company.class, id));
  }
  
  public void fetchEmployee(int id) //featching all the emplouyee data Refer case no 3 
  {
	// TODO Auto-generated method stub
	EntityManager entityManager= getEntityManager();
//	Query query = entityManager.createQuery("SELECT e FROM Employee e"); //JPQL query 

	//  jar JPQL query lihali tr method name madhe int id/ formal argument lihana garjech nahi
//	
//	Company company= entityManager.find(Company.class, id);
//	System.out.println(company);
	
                       // OR	
	
	System.out.println(entityManager.find(Employee.class, id));
  }
  
  public void fetchAllCompany()  //refaer case no 4 in mainController
  {
	  EntityManager entityManager=getEntityManager();
	  Query query = entityManager.createQuery("SELECT c FROM Employee c"); //JPQL query
	  
	  System.out.println(query.getResultList());
  }
  
  
  public void deleteCompany(int id)  //refer case no 5
  {
	  EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Company company = entityManager.find(Company.class, id);
		entityTransaction.begin();
		List<Employee> employees =company.getEmployees();
		
		for(Employee employee : employees)
		{
			entityManager.remove(employee);
		}
		entityManager.remove(company);
		entityTransaction.commit();
  }
  
  public void updateEmoloyee(Employee employee, int id)  //Update Employee data
  {
	  EntityManager entityManager=getEntityManager();
	  EntityTransaction entityTransaction= entityManager.getTransaction();
	  
	  Employee dbemployee= entityManager.find(Employee.class,id);
	  if(dbemployee !=null)
	  {
		  entityTransaction.begin();
	  //  company.setId(id);
		  entityManager.merge(employee);
		 
		  entityTransaction.commit();
	  }
  }
  
  public void updateCompany(Company company, int id)  //Update Employee data
  {
	  EntityManager entityManager=getEntityManager();
	  EntityTransaction entityTransaction= entityManager.getTransaction();
	  
	  Company dbcompany= entityManager.find(Company.class,id);
	  if(dbcompany !=null)
	  {
		  entityTransaction.begin();
	  //  company.setId(id);
		  entityManager.merge(company);
		  
		  company.setEmployees(dbcompany.getEmployees());
		  entityTransaction.commit();
	  }
  }
  
  public void updateComEmp(Company company, int id)
  {
	  EntityManager entityManager=getEntityManager();
	  EntityTransaction entityTransaction= entityManager.getTransaction();
	  
	  Company dbcompany= entityManager.find(Company.class,id);
	  if(dbcompany !=null)
	  {
		  entityTransaction.begin();
		  company.setId(id);
		  
		  List<Employee> employees = company.getEmployees();
		  for(Employee employee: employees)
		  {
		    entityManager.merge(employee);
		  }
		  entityManager.merge(company);
		  entityTransaction.commit();
	  }
  }
  
}
