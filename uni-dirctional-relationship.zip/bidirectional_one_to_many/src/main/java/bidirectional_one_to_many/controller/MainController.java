package bidirectional_one_to_many.controller;


import java.util.ArrayList;
import java.util.List;
import bidirectional_one_to_many_dao.CompanyDao;
import bidirectional_one_to_many_dao.EmployeeDao;
import bidirectional_one_to_many_dto.Company;
import bidirectional_one_to_many_dto.Employee;

public class MainController 
{
	public static void main(String[] args) 
	{
		Company company = new Company();
		
		CompanyDao ComDao=new CompanyDao();
		EmployeeDao EmpDao=new EmployeeDao();
		
		Employee e1=new Employee();
		    e1.setName("A");
		    e1.setPhone(1234567890l);
		    e1.setAddress("Pune");
	
		Employee e2=new Employee();
		    e2.setName("B");
		    e2.setPhone(1234568590l);
		    e2.setAddress("Pune");
		
		Employee e3=new Employee();
		    e3.setName("C");
		    e3.setPhone(1234567841l);
		    e3.setAddress("Pune");
		
		List<Employee> emp=new ArrayList<Employee>();
		   emp.add(e1);
		   emp.add(e2);
		   emp.add(e3);
		
		company.setEmployee(emp);
		
		ComDao.saveCompany(company);
		
		EmpDao.saveEmployee(e1);
		EmpDao.saveEmployee(e2);
		EmpDao.saveEmployee(e3);
	}
}
