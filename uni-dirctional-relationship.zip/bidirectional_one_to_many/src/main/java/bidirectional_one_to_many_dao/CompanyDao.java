package bidirectional_one_to_many_dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
 
import bidirectional_one_to_many_dto.Company;
import bidirectional_one_to_many_dto.Employee;
import bidirectional_one_to_many_dao.*;

public class CompanyDao 
{
	 public EntityManager getEntityManager()
	   {
		   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	   }
	 
	 public void saveCompany(Company company)
	 {
		 EntityManager entityManager=getEntityManager();
	     EntityTransaction entityTransaction=entityManager.getTransaction();
		 List<Employee> employees=company.getEmployee();
	
			entityTransaction.begin();
			for(Employee e: employees)
			{
				entityManager.persist(e);
			}
			entityTransaction.commit();		
	 }
}
