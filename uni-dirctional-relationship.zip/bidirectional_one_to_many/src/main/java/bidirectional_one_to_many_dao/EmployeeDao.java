package bidirectional_one_to_many_dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import bidirectional_one_to_many_dto.Employee;

public class EmployeeDao 
{
	public EntityManager getEntityManager()
	   {
		   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	   }
	 
	 public void saveEmployee(Employee emp)
	 {
		 EntityManager entityManager=getEntityManager();
	     EntityTransaction entityTransaction=entityManager.getTransaction();
			
			entityTransaction.begin();
			entityManager.persist(emp);
			entityTransaction.commit();
	 }
}
