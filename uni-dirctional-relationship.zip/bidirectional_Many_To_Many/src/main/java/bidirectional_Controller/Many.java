package bidirectional_Controller;

import java.util.Scanner;

import bidirectional_Many_To_Many_dac.CourseDao;
import bidirectional_Many_To_Many_dto.Student;

public class Many 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		CourseDao courseDao=new CourseDao();
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter choice \n1.Student Interface \n2.Course Interface");
		int choice=scanner.nextInt();
		
		switch (choice) 
		{
		case 1:
		  {
			System.out.println("Enter choice \n1.Save Studen \n2.Update Student");
			int keyStudent=scanner.nextInt();
			
			switch (keyStudent) 
			{
			case 1:
			  {
				System.out.println("Enter the course name : ");
				String name=scanner.next();
				
				System.out.println("Enter the course phone: ");
				long phone=scanner.nextLong();
				
				System.out.println("Enter the course address : ");
				String address=scanner.next();
				
				Student student=new Student();
				student.setName(name);
				student.setPhone(phone);
				student.setAddress(address);
				
				CourseDao.getAllCourse();
				System.out.println("");
       		  }
            break;
        
		   case 2:
		    {
			    System.out.println("Enter choice \n1.Save Course \n2.Update");
			    int keyCourse=scanner.nextInt();
			
			  switch (keyCourse) 
			   {
			   case 1:
			     {
				     System.out.println("Enter the course name : ");
				     String name=scanner.next();
				
				     System.out.println("Enter the course duration: ");
				     Double duration=scanner.nextDouble();
				
			     }
			    break;
			   case 2:
			   {
				   
			   }
			   break;
			   
			   default:
			     {
				    break;
			     }
			   }
		    }

		       default:
			      break;
			}
		  }
	   }   
	}
}
		
