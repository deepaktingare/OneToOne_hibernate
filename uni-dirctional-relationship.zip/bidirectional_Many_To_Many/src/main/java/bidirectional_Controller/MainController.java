package bidirectional_Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

import bidirectional_Many_To_Many_dac.CourseDao;
import bidirectional_Many_To_Many_dac.StudentDao;
import bidirectional_Many_To_Many_dto.Course;
import bidirectional_Many_To_Many_dto.Student;

public class MainController 
{
	public static void main(String[] args) 
	{
		StudentDao studentDao=new StudentDao();
		
		CourseDao courseDao=new CourseDao();
		
		Student s1=new Student();
		s1.setName("A");
		s1.setPhone(123l);
		s1.setAddress("Pune");
	
		
		Student s2=new Student();
		s2.setName("A");
		s2.setPhone(456l);
		s2.setAddress("Deccan");

		Student s3=new Student();
		s3.setName("c");
		s3.setPhone(789l);
		s3.setAddress("Wakad");
		
		Course c1=new Course();
		c1.setName("Java");
		c1.setFees(123l);
		c1.setDuration(6);
		
		Course c2=new Course();
		c2.setName("J2EE");
		c2.setFees(456l);
		c2.setDuration(3);
		
		Course c3=new Course();
		c3.setName("WebTech");
		c3.setFees(456l);
		c3.setDuration(3);
		
		List<Course> cou1=new ArrayList<Course>();
		cou1.add(c1);
		cou1.add(c2);
		cou1.add(c3);
		
		List<Course> cou2=new ArrayList<Course>();
		cou2.add(c1);
		cou2.add(c2);
		cou2.add(c3);
		
		List<Course> cou3=new ArrayList<Course>();
		cou3.add(c1);
		cou3.add(c2);
		cou3.add(c3);
		
		s1.setCourse(cou1);
		s1.setCourse(cou2);
		s1.setCourse(cou3);
		
		s2.setCourse(cou1);
		s2.setCourse(cou3);
		
		s3.setCourse(cou2);
		s3.setCourse(cou3);
		
		List<Student> stu1=new ArrayList<Student>();
		stu1.add(s1);
		stu1.add(s1);
		stu1.add(s1);
		
		List<Student> stu2=new ArrayList<Student>();
		stu2.add(s2);
		stu2.add(s2);
		
		List<Student> stu3=new ArrayList<Student>();
		stu3.add(s3);
		stu3.add(s3);
		
		c1.setStudent(stu1);
		c2.setStudent(stu2);
		c3.setStudent(stu3);
		
		studentDao.saveStudent(s1);
		studentDao.saveStudent(s2);
		studentDao.saveStudent(s3);
		
		courseDao.saveCourse(c1);
		courseDao.saveCourse(c2);
		courseDao.saveCourse(c3);
	}
}
