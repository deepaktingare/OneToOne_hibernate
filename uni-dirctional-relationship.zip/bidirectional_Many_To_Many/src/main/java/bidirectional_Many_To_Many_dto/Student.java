package bidirectional_Many_To_Many_dto;
//owining side
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Student 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	
	private int id;
//	private int sid;
	private String name;
	private String address;
	@Column(unique = true)
	private long phone;
//	@ManyToMany(cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE})
	
	@ManyToMany
	
//	@JoinTable(@JoinColumn=@JoinColumn(name="sid"),inverseJoinColumns=@JoinColumn(name="cid")) 
//  this join system using for reducing the no of table Ex- 4 table after join Only 3 table present
	List<Course> course;

//	public int getSId() {
//		return sid;
//	}
//
//	public void setSId(int sid) {
//		this.sid = sid;
//	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public List<Course> getCourse() {
		return course;
	}

	public void setCourse(List<Course> course) {
		this.course = course;
	}
	
	
}