package bidirectional_Many_To_Many_dac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import bidirectional_Many_To_Many_dto.Course;
import bidirectional_Many_To_Many_dto.Student;
import net.bytebuddy.build.Plugin.Engine.ErrorHandler.Enforcing;

public class CourseDao 
{
//	 public EntityManager getEntityManager()
//	   {
//		   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
//	   }
//	 
//	 public void saveCourse(Course course)
//	 {
//		 EntityManager entityManager=getEntityManager();
//	     EntityTransaction entityTransaction=entityManager.getTransaction();
//		 List<Student> student=course.getStudent();
//	
//			entityTransaction.begin();
//			for(Student stu: student)
//			{
//				entityManager.persist(stu);
//			}
//			entityTransaction.commit();
//			
//			
//	 }
	
	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("deepak");
	EntityManager entityManager=entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction=entityManager.getTransaction();
	
	public void saveCourse(Course course)
	{
		
	}

	public static void getAllCourse() {
		// TODO Auto-generated method stub
		
	}
}
