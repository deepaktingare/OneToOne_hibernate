package bidirectional_Many_To_Many_dac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import bidirectional_Many_To_Many_dto.Student;
import bidirectional_Many_To_Many_dto.Course;

import bidirectional_Many_To_Many_dac.CourseDao;
import bidirectional_Many_To_Many_dac.StudentDao;


public class StudentDao 
{
	 public EntityManager getEntityManager()
	   {
		   return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	   }
	 
	 public void saveStudent(Student student)
	 {
		 EntityManager entityManager=getEntityManager();
	     EntityTransaction entityTransaction=entityManager.getTransaction();
		 List<Course> course=student.getCourse();
		 
//		 entityTransaction.begin();
//			for(Course cou: course)
//			{
//				entityManager.persist(cou);
//			}
//			entityTransaction.commit();
         
		 entityTransaction.begin();
		 
		 entityManager.persist(student);
		 entityManager.persist(student);
		 entityManager.persist(student);
		 
		 entityManager.persist(course);
		 entityManager.persist(course);
		 entityManager.persist(course);
		 
		 entityTransaction.commit();
	 }
}
