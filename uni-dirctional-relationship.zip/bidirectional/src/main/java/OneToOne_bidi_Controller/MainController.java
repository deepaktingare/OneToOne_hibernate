package OneToOne_bidi_Controller;

import java.util.Scanner;

import One_to_one_bidi_Dao.AadharCard_Dao;
import One_to_one_bidi_Dao.PersoneDao;
import One_to_one_bidirectional.AadharCard;
import One_to_one_bidirectional.Persone;

public class MainController 
{
	public static void main(String[] args) 
	{
		Persone persone=new Persone();
		AadharCard aadharCard=new AadharCard();
		
		PersoneDao perDao =new PersoneDao();
		AadharCard_Dao aaDao=new AadharCard_Dao();
		
		Scanner sc=new Scanner(System.in);
		
		aadharCard.setPerson(persone);
		persone.setAadharCard(aadharCard);
		
//		persone.setName("Deepak");
//		persone.setAddress("karmala");
//		persone.setPhone(8520963740l);
//		
//		aadharCard.setAddress("Solapur");
//		aadharCard.setName("Deepak");
		
		persone.setName("Harshada");
		persone.setAddress("Mala");
		persone.setPhone(8585263740l);
		
		aadharCard.setAddress("kholapur");
		aadharCard.setName("Harshda");
		aadharCard.setPerson(persone);
		persone.setAadharCard(aadharCard);
		
//		persone.setName("Mahesh");
//		persone.setAddress("Kurduwadi");
//		persone.setPhone(012363740l);
//		
//		aadharCard.setAddress("Solapur");
//		aadharCard.setName("Mahesh");
//		
//		persone.setName("Rohit");
//		persone.setAddress("Madha");
//		persone.setPhone(851233740l);
//		
//		aadharCard.setAddress("Solapur");
//		aadharCard.setName("rohit");
//			
//		perDao.savePersone(persone); //for person save data & if you save insert data plese change cash cading 
		
//		perDao.deletePerson(4);  //for delete persone data & if you remove data plese change cash cading 
		perDao.updatePerson(persone,3);  // for update persone data & if you update/merge data plese change cash cading 
		 
		sc.close();
	}
}
