package One_to_one_bidi_Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import One_to_one_bidirectional.AadharCard;
import One_to_one_bidirectional.Persone;

public class PersoneDao 
{
	public EntityManager getEntityManager()
	{
		return Persistence.createEntityManagerFactory("deepak").createEntityManager();
	}
	public void savePersone(Persone persone) 
	{
		// TODO Auto-generated method stub
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		AadharCard aadharCard= persone.getAadharCard();
		
		entityTransaction.begin();
		entityManager.persist(aadharCard);
		entityManager.persist(persone);
		entityTransaction.commit();
	}
	public void deletepersone(Persone persone)
	{
		
	}
	
	public void featchpersone(int id) 
	{
		EntityManager entityManager=getEntityManager();
		Persone persone=entityManager.find(Persone.class, id);
		
		System.out.println(persone);
	}
	
	public void featchAllPersons()
	{
		EntityManager entityManager=getEntityManager();
		Query query=entityManager.createQuery("SELECT p FROM Persone p");
		System.out.println(query.getResultList());
	}
	
	public void deletePerson(int id)
	{
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction= entityManager.getTransaction();
		
		Persone persone=entityManager.find(Persone.class,id);
		
		if(persone!=null)
		{
			entityTransaction.begin();
			entityManager.remove(persone);
			entityTransaction.commit();
		}
	}
	
	public void updatePerson(Persone persone, int id)
	{
		EntityManager entityManager=getEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		Persone dbPersone=entityManager.find(Persone.class, id);
		if(dbPersone != null)
		{
			persone.setId(id);
			persone.getAadharCard().setId(dbPersone.getAadharCard().getId());
			
			entityTransaction.begin();
			entityManager.merge(persone);
			entityTransaction.commit();
		}
	}
}
